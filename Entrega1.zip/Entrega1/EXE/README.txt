Para ejecutar los tests:

En linux: ./DriverPartida.jar < test.txt
En windows: java -jar DriverPartida < test.txt

Hay algunos tests que no funcionan correctamente debido a la clase Scanner que no coge bien los valores de los ficheros .txt. Pero, si 
se introducen manualmente en los menus el comportamiento de los drivers es el mismo que en nuestra IDE de Java.

Excepciones que aparecen debido al scanner:
NoSuchElementException
InputMismatchException
