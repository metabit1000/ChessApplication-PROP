package ClasesExtra;

/**
 *
 * @author Àlex
 */
public class DriverMinimaxAlphaBeta {
    //Segunda entrega...
}
